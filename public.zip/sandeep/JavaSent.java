package mypack;

public class JavaSent {
public static void main(String args[]) throws Exception
{
	JavaMail.sendMail("sandeepkumaragnihotri927@gmail.com");
	
}
}
