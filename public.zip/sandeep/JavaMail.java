package mypack;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;




public class JavaMail
{
   public static void sendMail(String recepient) throws Exception
   {
	   Properties properties=new Properties();
	   properties.put("mail.smtp.auth", "true");
	   properties.put("mail.smtp.starttls.enable", "true");
	   properties.put("mail.smtp.host", "smtp.gmail.com");
	   properties.put("mail.smtp.port", "587");
	   String myAccount="servermonks0@gmail.com";
	   String password="qwerty@123";
	   Session session=Session.getInstance(properties ,new javax.mail.Authenticator() {
		   protected PasswordAuthentication getPasswordAuthentication() {
			   return new PasswordAuthentication(myAccount,password);
			   
		   }
		   
		   
	   });
	   Message message= prepareMessage(session,myAccount,recepient);
	   Transport.send(message);
	   System.out.println("message sent");
	   
	   
   }
   private static Message prepareMessage(Session session,String myAccount,String recepient)
   {
	   try
	   {
		   Message message =new MimeMessage(session);
		   message.setFrom(new InternetAddress(myAccount));
		   message.setRecipient(Message.RecipientType.TO,new InternetAddress(recepient));
		   message.setSubject("Otp for email verification");
		   message.setText("hello");
		   return message;
		   
		   
	   }
	   catch(Exception e) {
		   Logger.getLogger(JavaMail.class.getName()).log(Level.SEVERE ,null,e);
	   }
	   return null;
   }

}
